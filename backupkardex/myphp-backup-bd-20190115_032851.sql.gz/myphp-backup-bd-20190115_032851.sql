CREATE DATABASE IF NOT EXISTS `bd`;

USE `bd`;

SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `articulo`;

CREATE TABLE `articulo` (
  `idarticulo` int(11) NOT NULL AUTO_INCREMENT,
  `idcategoria` int(11) NOT NULL,
  `codigo` varchar(50) DEFAULT NULL,
  `contenido` text,
  `bodega` text NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `stock` decimal(11,2) NOT NULL,
  `descripcion` varchar(512) DEFAULT NULL,
  `imagen` varchar(512) DEFAULT NULL,
  `estado` varchar(20) NOT NULL,
  PRIMARY KEY (`idarticulo`),
  KEY `fk_articulo_categoria_idx` (`idcategoria`),
  CONSTRAINT `fk_articulo_categoria` FOREIGN KEY (`idcategoria`) REFERENCES `categoria` (`idcategoria`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

INSERT INTO `articulo` VALUES (2,4,"GRIS","25 KG","FERRECAMPO","MegaPega cerámico gris","100.00","Para la instalación de enchapes de cerámica, azulejos, baldosines, en paredes y pisos, sobre soportes de concreto, mortero o revoque, en sitios tales como baño, cocinas, lavanderías, etc.","megapega.jpg","Activo"),
(3,1,100,"1 Unidad","Proceramicas","Lavamanos Acuacer","9.00","Lavamanos de colgar Acuacer que facilita el uso y la accesibilidad, diseño moderno de lineas simples mas agradables que ofrecen mayor facilidad de limpieza.","073341000-320x320-main-image-320x320-73391001.jpg","Activo"),
(4,1,100,"1 Unidad","Proceramicas","Pedestal Acuacer","29.00","edestal cerámico cubre sifón ideal para darle una perspectiva elegante a tu lavamanos. Se recomienda seguir las instrucciones de uso y seguridad dispuestas por el fabricante Porcelana Sanitaria: limitada de por vida. Grifería: 5 años","pedestal-corona-acuacer-D_NQ_NP_782913-MCO26717916056_012018-F.jpg","Activo"),
(5,1,100,"1 Unidad","Proceramicas","Sanitario Laguna","10.00","Si lo que te gusta es un estilo más tradicional, elige este sanitario con taza y tanque separados, de piezas livianas y además los puedes reemplazar por separado","340021001-1000x1000.jpg","Activo"),
(6,5,"lote 104 v","(1.89x9 -- 45x45)","ferrecampo","lovaina beige","317.52","piso para exteriores","PISO_LOVAINA_BEIGE_45.8X45.8_2DA.PNG","Activo"),
(7,6,"485p","20.5x20.5 -- 1.51x36","proceramicas","NATAL BLANCO CU","12.11","espacios como el baño o paredes interiores.","201093001-1000x1000.jpg","Activo"),
(8,7,"lote 123v","(30x45 -- 1.5x11)","proceramicas","amarna gris","173.00","Pared fachaleta Amarna 30x45 con acabado satinado, color blanco y una única cara.","455839001-1000x1000-main-image-640x640-455839001.jpg","Activo"),
(9,8,105,"(2 kg )","Proceramicas","concolor beige","34.00","fragua","concolor.jpg","Activo"),
(10,4,"GRIS","25 KG","DECORPEGA","PEGACOR INTERIORES GRIS","100.00","Pegacor es un adhesivo en polvo premezclado en  fábrica, de base cementosa","pegacor-interior-logo-ntc-320x320-main-image-320x320-901061501.jpg","Activo");


DROP TABLE IF EXISTS `categoria`;

CREATE TABLE `categoria` (
  `idcategoria` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `descripcion` varchar(256) DEFAULT NULL,
  `condicion` tinyint(1) NOT NULL,
  PRIMARY KEY (`idcategoria`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

INSERT INTO `categoria` VALUES (1,"sanitarios-y-lavamanos","Para darle más estilo y espacio a tu baño, utiliza este combo compuesto por sanitario, lavamanos, con grifería y accesorios en porcelana.",1),
(2,"pantalonetas","marcas en todos los estilos",0),
(3,"BAÑOS","sanitarios, lavamanos y muebles exclusivos para que el baño de tu casa sea único.",1),
(4,"PEGANTES","te darán la confianza para trabajar tranquilo, es un adhesivo en polvo premezclado en fábrica para una mejor calidad.",1),
(5,"PISO","pisos para exteriores e interiores, los cuales darán estilo, amplitud y brillo a tus espacios.",1),
(6,"PISO-PARED","Piso-pared por su diseño puede ser utilizado en espacios como el baño o paredes interiores.",1),
(7,"FACHADA","paredes fachaleta para espacios exteriores Corona dan un toque de innovación a tu hogar",1),
(8,"CONCOLOR","Concolor junta estrecha es una mezcla de cemento, agregados finos, aditivos poliméricos y pigmentos que se homogenizan fácilmente con agua, con Formula antihongos,antialgas y disminución de eflorescencias.",1),
(9,"PARED","Paredes Corona. estilos y materiales que te permiten jugar con los espacios de tu hogar, creando atmósferas únicas y llenas de inspiración.",1);


DROP TABLE IF EXISTS `detalle_ingreso`;

CREATE TABLE `detalle_ingreso` (
  `iddetalle_ingreso` int(11) NOT NULL AUTO_INCREMENT,
  `idingreso` int(11) NOT NULL,
  `idarticulo` int(11) NOT NULL,
  `cantidad` decimal(11,2) NOT NULL,
  PRIMARY KEY (`iddetalle_ingreso`),
  KEY `fk_detalle_ingreso_idx` (`idingreso`),
  KEY `fk_detalle_ingreso_articulo_idx` (`idarticulo`),
  CONSTRAINT `fk_detalle_ingreso` FOREIGN KEY (`idingreso`) REFERENCES `ingreso` (`idingreso`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_detalle_ingreso_articulo` FOREIGN KEY (`idarticulo`) REFERENCES `articulo` (`idarticulo`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

INSERT INTO `detalle_ingreso` VALUES (1,4,3,"2.00"),
(2,4,3,"2.00"),
(3,5,3,"5.00"),
(4,6,4,"2.00"),
(5,7,3,"2.00"),
(6,8,6,"100.00"),
(7,9,6,"100.00"),
(8,10,7,"20.00"),
(9,11,7,"4.00"),
(10,12,7,"4.50"),
(11,13,8,"99.00"),
(12,14,8,"99.00"),
(13,15,9,"36.00");


DROP TABLE IF EXISTS `detalle_venta`;

CREATE TABLE `detalle_venta` (
  `iddetalle_venta` int(11) NOT NULL AUTO_INCREMENT,
  `idventa` int(11) NOT NULL,
  `idarticulo` int(11) NOT NULL,
  `cantidad` decimal(11,2) NOT NULL,
  PRIMARY KEY (`iddetalle_venta`),
  KEY `fk_detalle_venta_articulo_idx` (`idarticulo`),
  KEY `fk_detalle_venta_idx` (`idventa`),
  CONSTRAINT `fk_detalle_venta` FOREIGN KEY (`idventa`) REFERENCES `venta` (`idventa`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_detalle_venta_articulo` FOREIGN KEY (`idarticulo`) REFERENCES `articulo` (`idarticulo`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=latin1;

INSERT INTO `detalle_venta` VALUES (1,2,4,"1.00"),
(2,3,4,"1.00"),
(3,4,4,"1.00"),
(4,5,4,"1.00"),
(5,6,4,"1.00"),
(6,7,4,"1.00"),
(7,8,3,"1.00"),
(8,9,4,"1.00"),
(9,9,3,"11.00"),
(10,9,4,"1.00"),
(11,10,4,"3.00"),
(12,11,4,"3.00"),
(13,12,4,"3.00"),
(15,14,4,"1.00"),
(16,15,4,"2.00"),
(18,17,4,"6.00"),
(19,18,7,"1.00"),
(20,19,7,"5.00"),
(21,20,7,"4.00"),
(22,21,7,"4.50"),
(23,22,7,"4.89"),
(24,23,8,"98.00"),
(25,23,7,"4.00"),
(26,24,8,"12.00"),
(27,25,7,"1.00"),
(28,26,7,"1.00"),
(29,27,8,"1.00"),
(30,28,8,"1.00"),
(31,29,6,"12.00"),
(32,30,9,"2.00"),
(33,31,8,"12.00");


DROP TABLE IF EXISTS `ingreso`;

CREATE TABLE `ingreso` (
  `idingreso` int(11) NOT NULL AUTO_INCREMENT,
  `idproveedor` int(11) NOT NULL,
  `tipo_comprobante` varchar(20) NOT NULL,
  `num_comprobante` varchar(10) NOT NULL,
  `fecha_hora` datetime NOT NULL,
  `estado` varchar(20) NOT NULL,
  PRIMARY KEY (`idingreso`),
  KEY `fk_ingreso_persona_idx` (`idproveedor`),
  CONSTRAINT `fk_ingreso_persona` FOREIGN KEY (`idproveedor`) REFERENCES `persona` (`idpersona`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

INSERT INTO `ingreso` VALUES (1,4,"Boleta",00002,"2016-11-21 00:00:00","A"),
(2,6,"Factura",0007,"2016-11-21 00:00:00","A"),
(3,4,"Boleta",1110,"2016-11-21 00:00:00","A"),
(4,4,"Boleta"," 0007","2016-11-21 19:44:42","A"),
(5,6,"Boleta"," 0007","2016-11-21 19:49:33","A"),
(6,6,"Boleta"," 0007","2016-11-21 20:09:43","A"),
(7,4,"Boleta"," 00002","2016-11-26 16:23:17","A"),
(8,7,"Factura",909090,"2019-01-05 21:26:29","C"),
(9,7,"Factura",90999,"2019-01-05 21:29:08","C"),
(10,7,"Factura",123456,"2019-01-06 12:53:24","A"),
(11,4,"Boleta",45675,"2019-01-06 15:04:49","A"),
(12,7,"Boleta",23443,"2019-01-06 15:06:08","A"),
(13,7,"Factura",123321,"2019-01-09 21:06:13","A"),
(14,4,"Factura",456789,"2019-01-09 21:09:06","A"),
(15,7,"Factura",454543534,"2019-01-13 15:13:22","A");


DROP TABLE IF EXISTS `migrations`;

CREATE TABLE `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `migrations` VALUES ("2014_10_12_000000_create_users_table",1),
("2014_10_12_100000_create_password_resets_table",1),
("2014_10_12_000000_create_users_table",1),
("2014_10_12_100000_create_password_resets_table",1),
("2014_10_12_000000_create_users_table",1),
("2014_10_12_100000_create_password_resets_table",1),
("2014_10_12_000000_create_users_table",1),
("2014_10_12_100000_create_password_resets_table",1);


DROP TABLE IF EXISTS `password_resets`;

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY `password_resets_email_index` (`email`),
  KEY `password_resets_token_index` (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `persona`;

CREATE TABLE `persona` (
  `idpersona` int(11) NOT NULL AUTO_INCREMENT,
  `tipo_persona` varchar(20) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `tipo_documento` varchar(20) DEFAULT NULL,
  `num_documento` varchar(15) DEFAULT NULL,
  `direccion` varchar(70) DEFAULT NULL,
  `telefono` varchar(15) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`idpersona`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

INSERT INTO `persona` VALUES (1,"cliente","sebastian giraldo","CC",1112456789,NULL,NULL,"giraldinho@gmail.com"),
(2,"cliente","ana perez","CC",1112567098,NULL,NULL,"perezana@gmail.com"),
(3,"Cliente"," jose martinez","T.I","123456 ","calle 10 "," 321123456 ","jose@gmail.com"),
(4,"Proveedor"," Innovaciones Colombia S.A","RUT",0192837465,"avenida 5 #3-09","  3245909867","innocolombia@gmail.com"),
(5,"Inactivo"," COLOMBIA LTD","RUT",9876122345," calle tall"," 311234543","ltdcol@gmail.com"),
(6,"Proveedor"," excelsprot","RUT"," 2376947"," Av. Calle 6 # 32A-24"," 3108059756","exceldixon@yahoo.es"),
(7,"Proveedor","Tienda Cerámica, Hipercentro y Centros Corona  ","NIT"," 18000 510250  ","  Bogotá   ","018000 512030 ","servicioalclienteac@corona.com.co"),
(8,"Inactivo"," 33 x 33","PASS"," 1234567"," 1234567"," 76542","admin@cotecnova.com"),
(9,"Proveedor","sumicol","NIT",321321,NULL,32143556457,"sumicol@gmail.com"),
(10,"Proveedor","euroceramicas","NIT",54645654665,NULL,212334234,"esuroceramicas@gmail.com");


DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `users` VALUES (1,"luis","ibarguen1294@gmaill.com","$2y$10$AJru3NKSoDB0zNtGyKynBeyflOo7WLLiUoiPG9YGysSoCKKGI1rCq","rzNTqOYwDIxS96XIfcibraRaAXonw2e3mhUWWgrEILGjEfoey96N836qKXQ5","2016-11-22 09:55:35","2019-01-10 04:51:08"),
(2,"juan","juancarlos16@gmail.com","$2y$10$nXl8YVo3BOm5DMUU3J7uzufKNGgbOXy2RuCZXfbWp2/gUmNZE9E1m",NULL,"2016-11-22 11:08:21","2016-11-22 11:08:21"),
(4," pepe","r10@gmail.com","$2y$10$Q7/UyxaXH3bp5g2I6uQhD.SidgBKuszzV3hftH8S6yNWXXKGOx2K2",NULL,"2019-01-07 21:30:15","2019-01-07 21:30:15");


DROP TABLE IF EXISTS `venta`;

CREATE TABLE `venta` (
  `idventa` int(11) NOT NULL AUTO_INCREMENT,
  `idcliente` int(11) NOT NULL,
  `tipo_comprobante` varchar(20) NOT NULL,
  `num_comprobante` varchar(10) NOT NULL,
  `fecha_hora` datetime NOT NULL,
  `totalp` decimal(11,2) NOT NULL,
  `estado` varchar(20) NOT NULL,
  PRIMARY KEY (`idventa`),
  KEY `fk_venta_cliente_idx` (`idcliente`),
  CONSTRAINT `fk_venta_cliente` FOREIGN KEY (`idcliente`) REFERENCES `persona` (`idpersona`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=latin1;

INSERT INTO `venta` VALUES (1,1,"Boleta",0007,"2016-11-21 00:00:00","800.00","A"),
(2,1,"Boleta","  0007","2016-11-21 22:29:47","800.00","A"),
(3,3,"Boleta","  0007","2016-11-21 22:32:07","800.00","A"),
(4,1,"Boleta"," 0007","2016-11-21 22:35:24","800.00","A"),
(5,2,"Factura"," 0007","2016-11-21 22:37:07","800.00","A"),
(6,1,"Boleta"," 0007","2016-11-21 22:40:31","800.00","A"),
(7,1,"Boleta"," 0007","2016-11-21 23:23:04","800.00","A"),
(8,2,"Boleta"," 0007","2016-11-21 23:34:44","733733.00","A"),
(9,1,"Boleta",00007,"2018-12-29 22:02:16","6879899.00","A"),
(10,1,"Factura",321,"2018-12-30 14:18:10","2400.00","A"),
(11,1,"Boleta",4444,"2019-01-01 10:43:54","2399.00","A"),
(12,1,"Boleta",111111,"2019-01-02 20:13:59","2399.00","C"),
(14,1,"Factura",1234,"2019-01-05 18:54:30","800.00","A"),
(15,1,"Boleta",0009,"2019-01-05 18:57:28","1600.00","A"),
(17,3,"Factura",555,"2019-01-05 20:32:41","4800.00","C"),
(18,3,"Factura",3232,"2019-01-06 12:54:51","0.00","A"),
(19,2,"Factura",6767,"2019-01-06 13:48:28","0.00","C"),
(20,1,"Boleta",3434,"2019-01-06 15:03:31","0.00","A"),
(21,1,"Factura",5555,"2019-01-07 12:34:45","0.00","A"),
(22,2,"Factura",545656,"2019-01-07 16:36:00","0.00","A"),
(23,2,"Ticket",1111,"2019-01-09 22:40:23","0.00","C"),
(24,1,"Boleta",4434,"2019-01-10 22:43:42","12.00","A"),
(25,1,"Boleta",123453,"2019-01-12 19:24:18","1.00","A"),
(26,2,"Factura",565434,"2019-01-12 19:35:24","1.00","A"),
(27,1,"Boleta",3618,"2019-01-12 21:37:41","1.00","A"),
(28,1,"Exhibición","cscscsc","2019-01-12 21:51:10","1.00","C"),
(29,1,"Brilla",000,"2019-01-13 13:45:26","12.00","C"),
(30,2,"Factura",33212,"2019-01-13 22:26:43","2.00","A"),
(31,3,"Factura",32121,"2019-01-14 19:29:51","12.00","A");


SET foreign_key_checks = 1;
